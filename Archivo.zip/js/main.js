// js/main.js
document.addEventListener("DOMContentLoaded", async function () {
    const days = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"];
    
    const savedDayIndex = initializeDayIndex();
    const { exercisesData, foodData } = await fetchData(); // Asegúrate de que fetchData sea async

    if (exercisesData && foodData) {
        setupDashboard(days, savedDayIndex, exercisesData, foodData); // Pasa `days` aquí
        setupTabSwitching();
    } else {
        console.error("No se pudieron cargar los datos necesarios.");
    }
});