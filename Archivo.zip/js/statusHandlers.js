// js/statusHandlers.js

function attachStatusButtonHandlers(dayIndex, exercisesData, foodData) {
    const statusButtons = document.querySelectorAll('.status-button');
    statusButtons.forEach((button) => {
        button.addEventListener('click', function () {
            const itemType = button.getAttribute('data-type');
            const itemName = button.getAttribute('data-name');
            const currentState = button.getAttribute('data-state');
            const newState = toggleState(currentState);

            button.setAttribute('data-state', newState);
            updateButtonState(button, newState);
            saveStatusItem(itemType, dayIndex, itemName, newState);
            updateDashboard(dayIndex, exercisesData, foodData);
        });
    });
}

function toggleState(currentState) {
    switch (currentState) {
        case 'pendiente': return 'hecho';
        case 'hecho': return 'omitido';
        default: return 'pendiente';
    }
}