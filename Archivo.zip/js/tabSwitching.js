// js/tabSwitching.js

function setupTabSwitching() {
    const exerciseTabButton = document.getElementById('exerciseTabButton');
    const foodTabButton = document.getElementById('foodTabButton');
    const exercisePanelContainer = document.getElementById('exercisePanelContainer');
    const foodPanelContainer = document.getElementById('foodPanelContainer');

    exerciseTabButton.addEventListener('click', function () {
        togglePanels(exercisePanelContainer, foodPanelContainer, exerciseTabButton, foodTabButton);
    });

    foodTabButton.addEventListener('click', function () {
        togglePanels(foodPanelContainer, exercisePanelContainer, foodTabButton, exerciseTabButton);
    });
}

function togglePanels(showPanel, hidePanel, activateButton, deactivateButton) {
    showPanel.classList.remove('d-none');
    hidePanel.classList.add('d-none');
    activateButton.classList.add('active');
    deactivateButton.classList.remove('active');
}